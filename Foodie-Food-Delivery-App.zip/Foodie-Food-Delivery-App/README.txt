FOODIE - ONLINE FOOD DELIVERY FRONTEND PROJECT

HOW TO RUN
1. Extract the ZIP file.
2. Open the Foodie-Food-Delivery-App folder in Visual Studio Code.
3. Open index.html.
4. Right-click and choose "Open with Live Server" (recommended).
   You can also double-click index.html to open it in a browser.

FILES
- index.html : website structure
- style.css  : responsive design and styling
- script.js  : food listing, search, filters, cart, checkout and localStorage

FEATURES
- Responsive homepage and navigation
- Food categories and search
- Sort by price and rating
- Add to cart and quantity controls
- Remove items from cart
- Cart persists using browser localStorage
- Checkout form validation
- Demo order confirmation
- Guest profile information modal

IMPORTANT PROJECT NOTE
This is a frontend-only college project. It does not connect to a real server,
restaurant, delivery partner, or payment gateway. "Demo UPI" does not collect
money. Cart data is stored locally in the browser.

CUSTOMIZATION
Edit the foods array near the top of script.js to add or change food items.
