const foods = [
  {id:1,name:"Margherita Pizza",category:"Pizza",price:199,rating:4.8,emoji:"🍕",desc:"Classic cheese, tomato and fresh basil.",tag:"BESTSELLER"},
  {id:2,name:"Farmhouse Pizza",category:"Pizza",price:279,rating:4.7,emoji:"🍕",desc:"Loaded with capsicum, onion and veggies.",tag:"POPULAR"},
  {id:3,name:"Cheese Burst Burger",category:"Burger",price:149,rating:4.9,emoji:"🍔",desc:"Crispy patty with a rich cheese centre.",tag:"MUST TRY"},
  {id:4,name:"Classic Veg Burger",category:"Burger",price:119,rating:4.5,emoji:"🍔",desc:"A tasty veggie patty with fresh lettuce.",tag:""},
  {id:5,name:"Hyderabadi Biryani",category:"Biryani",price:249,rating:4.9,emoji:"🍛",desc:"Aromatic rice with authentic spices.",tag:"CHEF'S PICK"},
  {id:6,name:"Paneer Biryani",category:"Biryani",price:219,rating:4.6,emoji:"🍛",desc:"Fragrant basmati rice and soft paneer.",tag:""},
  {id:7,name:"Chocolate Brownie",category:"Dessert",price:99,rating:4.8,emoji:"🍫",desc:"Warm, fudgy and full of chocolate.",tag:"SWEET DEAL"},
  {id:8,name:"Strawberry Cake",category:"Dessert",price:129,rating:4.7,emoji:"🍰",desc:"Soft sponge layered with strawberry cream.",tag:""},
  {id:9,name:"Cold Coffee",category:"Drinks",price:89,rating:4.5,emoji:"🥤",desc:"Chilled creamy coffee to refresh your day.",tag:""},
  {id:10,name:"Fresh Lime Soda",category:"Drinks",price:59,rating:4.4,emoji:"🍹",desc:"Refreshing sweet and tangy lime soda.",tag:""}
];

let activeCategory = "All";
let cart = JSON.parse(localStorage.getItem("foodieCart") || "[]");
let toastTimer;

const $ = id => document.getElementById(id);
const rupees = amount => "₹" + amount.toLocaleString("en-IN");

function renderFoods() {
  const query = $("menuSearch").value.trim().toLowerCase();
  let visible = foods.filter(food =>
    (activeCategory === "All" || food.category === activeCategory) &&
    (food.name.toLowerCase().includes(query) || food.category.toLowerCase().includes(query))
  );
  const sort = $("sortSelect").value;
  if (sort === "low") visible.sort((a,b) => a.price-b.price);
  if (sort === "high") visible.sort((a,b) => b.price-a.price);
  if (sort === "rating") visible.sort((a,b) => b.rating-a.rating);

  $("foodGrid").innerHTML = visible.map(food => `
    <article class="food-card">
      <div class="food-photo">
        ${food.tag ? `<span class="food-label">${food.tag}</span>` : ""}
        <span aria-label="${food.category}">${food.emoji}</span>
      </div>
      <div class="food-info">
        <div class="food-title-row"><h3>${food.name}</h3><span class="rating">★ ${food.rating}</span></div>
        <p class="food-desc">${food.desc}</p>
        <div class="food-bottom"><span class="food-price">${rupees(food.price)}</span>
          <button class="add-btn" data-add="${food.id}">+ Add</button></div>
      </div>
    </article>`).join("");
  $("emptyState").classList.toggle("hidden", visible.length !== 0);
}

function saveCart() {
  localStorage.setItem("foodieCart", JSON.stringify(cart));
  renderCart();
}

function addToCart(id) {
  const food = foods.find(item => item.id === Number(id));
  const existing = cart.find(item => item.id === food.id);
  if (existing) existing.quantity += 1;
  else cart.push({...food, quantity:1});
  saveCart();
  showToast(`${food.name} added to cart`);
}

function changeQuantity(id, amount) {
  const item = cart.find(food => food.id === Number(id));
  if (!item) return;
  item.quantity += amount;
  if (item.quantity <= 0) cart = cart.filter(food => food.id !== Number(id));
  saveCart();
}

function renderCart() {
  const count = cart.reduce((sum,item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum,item) => sum + item.price * item.quantity, 0);
  const delivery = subtotal === 0 || subtotal >= 499 ? 0 : 30;
  $("cartCount").textContent = count;
  $("drawerCount").textContent = `(${count})`;
  $("cartItems").innerHTML = cart.map(item => `
    <div class="cart-row">
      <div class="cart-thumb">${item.emoji}</div>
      <div><h4>${item.name}</h4><small>${rupees(item.price)} each</small>
        <div class="qty-controls">
          <button data-qty="${item.id}" data-change="-1" aria-label="Decrease quantity">−</button>
          <b>${item.quantity}</b>
          <button data-qty="${item.id}" data-change="1" aria-label="Increase quantity">+</button>
        </div>
      </div>
      <button class="remove-item" data-remove="${item.id}" aria-label="Remove ${item.name}">×</button>
    </div>`).join("");
  $("cartEmpty").classList.toggle("hidden", count > 0);
  $("cartSummary").classList.toggle("hidden", count === 0);
  $("subtotal").textContent = rupees(subtotal);
  $("deliveryFee").textContent = delivery === 0 ? "FREE" : rupees(delivery);
  $("grandTotal").textContent = rupees(subtotal + delivery);
}

function openCart() {
  $("cartDrawer").classList.add("open");
  $("overlay").classList.add("show");
}
function closeCart() {
  $("cartDrawer").classList.remove("open");
  $("overlay").classList.remove("show");
}
function showModal(id) {
  closeCart();
  $(id).classList.remove("hidden");
  $("overlay").classList.add("show");
}
function closeModals() {
  document.querySelectorAll(".modal").forEach(modal => modal.classList.add("hidden"));
  $("overlay").classList.remove("show");
}
function showToast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("toast").classList.remove("show"), 2200);
}

$("foodGrid").addEventListener("click", event => {
  const button = event.target.closest("[data-add]");
  if (button) addToCart(button.dataset.add);
});
$("cartItems").addEventListener("click", event => {
  const qty = event.target.closest("[data-qty]");
  const remove = event.target.closest("[data-remove]");
  if (qty) changeQuantity(qty.dataset.qty, Number(qty.dataset.change));
  if (remove) {
    cart = cart.filter(item => item.id !== Number(remove.dataset.remove));
    saveCart();
  }
});
$("categoryGrid").addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (!button) return;
  activeCategory = button.dataset.category;
  document.querySelectorAll(".category-card").forEach(card => card.classList.toggle("selected", card === button));
  renderFoods();
  $("menu").scrollIntoView({behavior:"smooth"});
});
$("menuSearch").addEventListener("input", renderFoods);
$("sortSelect").addEventListener("change", renderFoods);
function runHeroSearch() {
  $("menuSearch").value = $("heroSearch").value;
  activeCategory = "All";
  document.querySelectorAll(".category-card").forEach(card => card.classList.toggle("selected", card.dataset.category === "All"));
  renderFoods();
  $("menu").scrollIntoView({behavior:"smooth"});
}
$("heroSearchBtn").addEventListener("click", runHeroSearch);
$("heroSearch").addEventListener("keydown", event => { if (event.key === "Enter") runHeroSearch(); });
$("showAllBtn").addEventListener("click", () => {
  activeCategory = "All"; $("menuSearch").value = ""; renderFoods();
  document.querySelectorAll(".category-card").forEach(card => card.classList.toggle("selected", card.dataset.category === "All"));
  $("menu").scrollIntoView({behavior:"smooth"});
});
$("promoOrderBtn").addEventListener("click", () => $("menu").scrollIntoView({behavior:"smooth"}));
$("cartOpenBtn").addEventListener("click", openCart);
$("cartCloseBtn").addEventListener("click", closeCart);
$("overlay").addEventListener("click", () => { closeCart(); closeModals(); });
$("browseBtn").addEventListener("click", () => { closeCart(); $("menu").scrollIntoView({behavior:"smooth"}); });
$("checkoutBtn").addEventListener("click", () => showModal("checkoutModal"));
$("profileBtn").addEventListener("click", () => showModal("profileModal"));
document.querySelectorAll("[data-close-modal]").forEach(button => button.addEventListener("click", closeModals));
$("doneBtn").addEventListener("click", () => { closeModals(); $("menu").scrollIntoView({behavior:"smooth"}); });
$("checkoutForm").addEventListener("submit", event => {
  event.preventDefault();
  if (!cart.length) return;
  const form = new FormData(event.target);
  const name = form.get("name").trim();
  const orderId = "FD" + Date.now().toString().slice(-7);
  const total = cart.reduce((sum,item) => sum + item.price * item.quantity, 0);
  const fee = total >= 499 ? 0 : 30;
  $("successMessage").textContent = `Thank you, ${name}! Your demo order total is ${rupees(total + fee)}. No real payment has been collected.`;
  $("orderNumber").textContent = "ORDER ID: " + orderId;
  cart = [];
  saveCart();
  event.target.reset();
  $("checkoutModal").classList.add("hidden");
  $("successModal").classList.remove("hidden");
});
$("menuToggle").addEventListener("click", () => $("mainNav").classList.toggle("open"));
document.querySelectorAll(".nav-link").forEach(link => link.addEventListener("click", () => $("mainNav").classList.remove("open")));
$("year").textContent = new Date().getFullYear();

renderFoods();
renderCart();
